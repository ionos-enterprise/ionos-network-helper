param(
    [string]$inf, 

    [ValidateNotNullOrEmpty()]
    [string]$idmatch="PCI\VEN_1AF4&DEV_1000&SUBSYS_00011AF4",

    [switch]$cleanupfirst,

    [switch]$nodevupdate,

    [switch]$list
)

$ErrorActionPreference = "Stop"

$my_path = split-path -parent $MyInvocation.MyCommand.Definition
$devcon = "$my_path\devcon.exe"

Import-Module -Name "$my_path\util.psm1"

$inf_path = ""

function get-driver-dir() {
  $dir = get-osver
  return $my_path + "\drivers\" + $dir + "\amd64"
}

function inf-del([string]$inf) {
  Write-Host "Cleaning up old driver package supplied by $inf .."
  invoke-cmd pnputil -f -d $inf
}

function inf-check([string]$infpath, [string]$skips) {
  $oeminf = Split-Path -Path $infpath -leaf
  If (-Not ($skips.Contains($oeminf))) {
    inf-del -inf $oeminf
  }
}

function inf-install([string]$infpath) {
  Write-Host "Installing driver package from $infpath"
  $output = invoke-cmd pnputil -a $infpath
  $installedinfs = @($output | select-string -Pattern 'oem[0-9]+\.inf' -AllMatches | % { $_.Matches } | % {$_.Value})
  Write-Host "New driver package is installed as $installedinfs"
  return $installedinfs
}

function inf-find([string]$match) {
  $infpaths = findstr /m "$match" "$Env:windir\inf\oem*.inf"
  return $infpaths
}

function dev-update([string]$infpath, [string]$idmatch) {
  $out = &$devcon find "$idmatch"
  $pattern = ([Regex]::Escape($idmatch)) + "[\&0-9A-Z_]*"
  $devids = @($out | select-string -Pattern "$pattern" -AllMatches | % { $_.Matches } | % {$_.Value} | Sort | Get-Unique)
  foreach ($id in $devids) {
    Write-Host "Updating Driver for devices $id from $infpath .."
    invoke-cmd $devcon update "$infpath" "$id"
  }
}

function update([string]$infpath, [string]$idmatch, [switch]$nodevupdate) {
  $newinfs = inf-install -infpath $infpath
  if (-Not($nodevupdate)) {
    dev-update -infpath $infpath -idmatch $idmatch
  }
  return $newinfs 
}

function update-cleanup([string]$infpath, [string]$idmatch, [switch]$nodevupdate) {
  $curpaths = inf-find -match $idmatch
  $newinfs = update -infpath $infpath -idmatch $idmatch -nodevupdate:$nodevupdate
  if ($curpaths) {
    $curpaths | ForEach-Object { inf-check -infpath $_ -skips $newinfs }
  }
}

function cleanup-update([string]$infpath, [string]$idmatch, [switch]$nodevupdate) {
  $curpaths = inf-find -match $idmatch
  if ($curpaths) {
    $curpaths | ForEach-Object { inf-check -infpath $_ }
  }
  $newinfs = update -infpath $infpath -idmatch $idmatch -nodevupdate:$nodevupdate
}

function validate-args() {
  if ($inf) {
    $global:inf_path = $inf
  } else {
    $path = get-driver-dir
    $global:infpath = $path + '\netkvm.inf'
  }
}

function main() {
  $osver = get-osver
  validate-args
  if ($list) {
    $curpaths = inf-find -match $idmatch
    Write-Output $curpaths
    Exit 0
  }
  $func_name = "update-cleanup"
  if ($cleanupfirst) {
    $func_name = "cleanup-update"
  }
  &"$func_name" -infpath "$global:infpath" -idmatch "$idmatch" -nodevupdate:$nodevupdate
  Write-Host "Driver Update Done!"
}

main


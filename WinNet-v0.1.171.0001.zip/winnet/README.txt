This package contains scripts and virtio-net drivers which enable
optimal network settings for IONOS Cloud-supported Windows guests.

The update.cmd script is the main entry point for performing
the desired modifications.

Just run "update.cmd -h" for all the detail on how to use it.

The virtio-net drivers supplied with the package are taken from
https://fedorapeople.org/groups/virt/virtio-win/direct-downloads/latest-virtio/virtio-win.iso

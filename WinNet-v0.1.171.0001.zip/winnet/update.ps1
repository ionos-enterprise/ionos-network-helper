param(
        [string]$mode,
        [switch]$help
)

$ErrorActionPreference = "Stop"

$my_path = split-path -parent $MyInvocation.MyCommand.Definition

$modes = @{
  "a"        = "run-all"
  "all"      = "run-all"
  "s"        = "run-store"
  "store"    = "run-store"
  "q"        = "run-quit"
  "quit"     = "run-quit"
  "o"        = "run-offloads"
  "offloads" = "run-offloads"
  "r"        = "run-reset"
  "reset"    = "run-reset"
  "p"        = "run-packages"
  "packages" = "run-packages"
}

$help_hdr = "
This script is used for configuring optimal settings
for Virtual Network Adaptors in IONOS Cloud VMs
"

$help_pref_ask = "
The script is running in interactive mode.
Please run 'update -help' for information on how to run it non-interactively.

Please specify the operation to execute:
"

$help_pref_run = "
Usage: 

update -help
    Print this help and exit.

update
    Interactive mode (user is asked what to do).

update -mode <mode>
    Do modification to the system based on the mode value specified,
    where mode is one of the following:
"

$help_base = "
a or all
    update settings and reset network adaptors to pick the new settings up.
    NOTE: This would cause a breakage of existing network connections!

s or store
    update settings but do not touch network adaptors.
    NOTE: This would result in the currently existing network adaptors to run
    with the old settings until they are manually reset, or system is rebooted.
"
$help_suf_ask = "
q or quit
    do nothing and quit.
"
$help_suf_run = "
"

$help_run = $help_hdr + $help_pref_run + $help_base + $help_suf_run
$help_ask = $help_hdr + $help_pref_ask + $help_base + $help_suf_ask

function help() {
  Write-Host $help_run
}

function select-run([string]$mode) {
  if (-Not($mode)) {
    Write-Host "no input specified"    
    return 1
  }

  if (-Not($modes.ContainsKey($mode))) {
    Write-Host "Unsuported input: $mode"
    help
    exit 1
  }

  $run = $modes[$mode]
  &"$run"
}

function run-quit() {
  exit 1
}

function run-offloads() {
  powershell -executionpolicy bypass -file settings.ps1 -offloads on
}

function run-packages() {
  powershell -executionpolicy bypass -file drv.ps1 -list
}

function run-reset() {
  powershell -executionpolicy bypass -file settings.ps1
}

function run-all() {
  powershell -executionpolicy bypass -file "$my_path\settings.ps1" -mtu 1500 -offloads on -nodevrestart
  if (-Not($?)) {
    Write-Host "Settings update failed"
    exit 1
  }

  powershell -executionpolicy bypass -file "$my_path\drv.ps1"
  if (-Not($?)) {
    Write-Host "Driver update failed"
    exit 1
  }
}

function run-store() {
  powershell -executionpolicy bypass -file "$my_path\drv.ps1" -nodevupdate
  if (-Not($?)) {
    Write-Host "Driver update failed"
    exit 1
  }

  powershell -executionpolicy bypass -file "$my_path\settings.ps1" -mtu 1500 -offloads on -nodevrestart
  if (-Not($?)) {
    Write-Host "Settings update failed"
    exit 1
  }
}

function main() {
  if ($help) {
    help
    exit 1
  }

  if (-Not($mode)) {
    $mode = Read-Host -Prompt $help_ask
  }
  select-run -mode $mode
}

if ($env:PROCESSOR_ARCHITEW6432 -eq "AMD64") {
  Write-Warning "Running in 32bit mode on 64bit system, switching to 64bit.."
  if ($MyInvocation.Line) {
    &"$Env:WINDIR\sysnative\windowspowershell\v1.0\powershell.exe" -executionpolicy bypass $MyInvocation.Line
  } else {
    &"$Env:WINDIR\sysnative\windowspowershell\v1.0\powershell.exe" -executionpolicy bypass -file "$($MyInvocation.InvocationName)" $args
  }
  exit $LastExitCode
}

main


param(
        [string]$offloads="",
        [string]$mtu="",
        [switch]$nodevrestart,
        [string]$offlinepath=""
)

$ErrorActionPreference = "Stop"

$my_path = split-path -parent $MyInvocation.MyCommand.Definition
Import-Module -Name "$my_path\util.psm1"

$service="netkvm"

$net_settings_on = @{
        "IPv4 Checksum Offload"="Rx & Tx Enabled"
        "Large Send Offload V2 (IPv4)"="Enabled"
        "Large Send Offload V2 (IPv6)"="Enabled"
        "Offload.Rx.Checksum"="All"
        "Offload.Tx.Checksum"="All"
        "Offload.Tx.LSO"="Maximal"
        "TCP Checksum Offload (IPv4)"="Rx & Tx Enabled"
        "TCP Checksum Offload (IPv6)"="Rx & Tx Enabled"
        "UDP Checksum Offload (IPv4)"="Rx & Tx Enabled"
        "UDP Checksum Offload (IPv6)"="Rx & Tx Enabled"
}

$reg_offline_mount_point_name = 'Offline'
$reg_offline_mount_point = 'HKLM' + '\' + $reg_offline_mount_point_name
$reg_root_prefix_offline = 'HKEY_LOCAL_MACHINE\' + $reg_offline_mount_point_name + '\ControlSet001'
$reg_root_prefix_online = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet'
$reg_root_suffix = 'Control\Class\{4D36E972-E325-11CE-BFC1-08002BE10318}'
$reg_hive_path = 'Windows\System32\config\SYSTEM'

$reg_settings_on = @{
        "*IPChecksumOffloadIPv4"=3
        "*LSOV2IPv4"=1
        "*LSOV2IPv6"=1
        "Offload.RxCS"=31
        "Offload.TxChecksum"=31
        "Offload.TxLSO"=2
        "*TCPChecksumOffloadIPv4"=3
        "*TCPChecksumOffloadIPv6"=3
        "*UDPChecksumOffloadIPv4"=3
        "*UDPChecksumOffloadIPv6"=3
}

function update-dev-new([string]$connection, [string]$mtu="", [string]$offloads="") {
  if ($offloads) {
    Write-Host "Prop: Setting offloads to $offloads for $connection"
    foreach ($key in $net_settings_on.keys) {
      $value = "Disabled"
      if ($offloads -eq "on") {
        $value = $net_settings_on[$key]
      }
      Set-NetAdapterAdvancedProperty $connection -DisplayName $key -DisplayValue $value -NoRestart
    }
  }
  if ($mtu) {
    Write-Host "Prop: Updating MTU to $MTU for $connection"
    Set-NetAdapterAdvancedProperty $connection -DisplayName "Init.MTUSize" -DisplayValue $mtu
  }
}

function update-reg([string]$mtu="", [string]$offloads="", [string]$offlinepath) {
  if ($offlinepath) {
    $hive_path = "$offlinepath\$reg_hive_path"
    Write-Host "Loading $hive_path .."
    $out = invoke-cmd reg load "$reg_offline_mount_point" "$hive_path"
    $reg_root_prefix = $reg_root_prefix_offline
  } else {
    $reg_root_prefix = $reg_root_prefix_online
  }
  $reg_root = $reg_root_prefix + "\" + $reg_root_suffix
  $items = Get-ChildItem -Path Registry::$reg_root -Name | Select-String "\d\d\d\d"
  Foreach ($item in $items) {
    $path = $reg_root + "\" + $item
    $srv_name = Get-ItemProperty -Path "Registry::$path\Ndi" | Select-Object -expandproperty Service
    if ($srv_name -eq $service) {
      if ($offloads) {
        Write-Host "Reg: Setting offloads to $offloads for $path"
        foreach ($key in $reg_settings_on.keys) {
          $value = "0"
          if ($offloads -eq "on") {
            $value = $reg_settings_on[$key]
          }
          Set-ItemProperty -path Registry::$path -Name $key -Value $value
        }
      }
      if ($mtu) {
        Write-Host "Reg: Updating MTU to $MTU for $path"
        Set-ItemProperty -path Registry::$path -Name "Init.MTUSize" -Value $mtu
        Set-ItemProperty -path Registry::$path -Name "MTU" -Value $mtu
      }
    }
  }

  if ($offlinepath) {
    Write-Host "Unloading $hive_path .."
    $out = reg unload "$reg_offline_mount_point"
  }
}

function get-net-adaptors() {
  return Get-WmiObject Win32_NetworkAdapter | Select ServiceName,NetConnectionID | Where-Object {$_.ServiceName -eq 'netkvm'}
}

function update-new([string]$mtu="", [string]$offloads="") {
  $net_adaptors = get-net-adaptors
  foreach ($adaptor in $net_adaptors) {
    $conid = $adaptor.NetConnectionID
    update-dev-new -connection "$conid" -mtu $mtu -offloads $offloads
  }

  # still need to update registry to make sure
  # the settings for removed adaptors are updated
  # This covers the case when a vnic with old settings was unplugged
  # and then later on a new vnic is plugged in the same slot
  update-reg -mtu $mtu -offloads $offloads
}

function update-old([string]$mtu="", [string]$offloads="", [switch]$nodevrestart, [string]$offlinepath) {
  update-reg -mtu $mtu -offloads $offloads -offlinepath $offlinepath

  if (-Not($nodevrestart) -and -Not($offlinepath)) {
    $net_adaptors = get-net-adaptors
    foreach ($adaptor in $net_adaptors)  {
      $conid = $adaptor.NetConnectionID
      Write-Host "Stopping $conid .."
      netsh interface set interface "$conid" disable
      Write-Host "Starting $conid .."
      netsh interface set interface "$conid" enable
      Write-Host "Ready $conid"
    }
  }
}

function update([string]$mtu="", [string]$offloads="", [switch]$nodevrestart, [string]$offlinepath) {
  $osver = get-osver
  $upnew = $false
  if (-Not($nodevrestart) -and -Not($offlinepath)) {
    $ver = [System.Environment]::OSVersion.Version
    if (($ver.Major -gt 6) -or (($ver.Major -eq 6) -and ($ver.Minor -ge 2))) {
      $upnew = $true
    }
  }

  if ($upnew) {
    update-new -mtu $mtu -offloads $offloads
  } else {
    update-old -mtu $mtu -offloads $offloads -nodevrestart:$nodevrestart -offlinepath $offlinepath
  }
  Write-Host "Settings Update Done"
}

update -mtu $mtu -offloads $offloads -nodevrestart:$nodevrestart -offlinepath $offlinepath

function invoke-cmd() {
#  $args
  $out = & $args[0] $args[1..$args.Length]
  if (-Not($?)) {
    Write-Host "ERROR Executing " $args
    Write-Host "Output : " $out
    exit 1
  }
  return $out
}


$drivers_dict = @{
  '10.0.18362' = '2k19'
  '10.0.17763' = '2k19'
  '10.0.17134' = '2k16'
  '10.0.16299' = '2k16'
  '10.0.15063' = '2k16'
  '10.0.14393' = '2k16'
  '10.0.10586' = '2k16'
  '6.3.9600'   = '2k12R2'
  '6.1.7601'   = '2k8R2'
  '6.1.7600'   = '2k8R2'
}

function get-osver() {
  $os = Get-WmiObject Win32_OperatingSystem
  $osver = $os.Version
  $osarch = $os.OSArchitecture
  if ($osarch -ne '64-bit') {
    Write-Host "ERROR: Unsupported OS Architecture $osarch"    
    exit 1
  }

  if ($drivers_dict.ContainsKey($osver)) {
     return $drivers_dict[$osver]
  }

  Write-Host "ERROR: Unsupported OS Version $osver"
  exit 1
}

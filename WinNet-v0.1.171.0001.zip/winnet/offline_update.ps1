param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$offlinepath
)

$ErrorActionPreference = "Stop"

$my_path = split-path -parent $MyInvocation.MyCommand.Definition

powershell -file "$my_path\settings.ps1" -offlinepath "$offlinepath" -offloads on -mtu 1500
